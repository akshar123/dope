import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { AlertController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  [x: string]: any;
  // credentials = {
  //   email: 'akshar111@gmail.com',
  //   pw: '123'
  // };
  Users: any = [];

  // constructor(private auth: AuthService, private alertCtrl: AlertController, private router: Router) { }
constructor(
  private authService: AuthService,
  private router: Router  
){}
  ngOnInit() {
  }

login(){
  this.authService.getUsers().subscribe(async (response) => {
    this.Users = response;
    // this.router.navigateByUrl('/members');
    if (response) {
      this.router.navigateByUrl('/members');
    } else {
      const alert = await this.alertCtrl.create({
        header: 'Login Failed',
        message: 'Wrong credentials.',
        buttons: ['OK']
      });
      await alert.present();
    }
  });
}

}