import { Component, OnInit , NgZone  } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder } from '@angular/forms';
import { AuthService } from '../services/auth.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {

userForm: FormGroup;//

  constructor(public router :Router,
    public formBuilder: FormBuilder,
    private zone: NgZone,
    private authService: AuthService) {
      this.userForm = this.formBuilder.group({
        name: [''],
        email: [''],
        password: [''],
        confirm_password: ['']
      });
     }
  ngOnInit() {
  }
  onSubmit() {
    
    if (!this.userForm.valid) {
      return false;
    } else {
      this.authService.createUser(this.userForm.value)
        .subscribe((response) => {
          this.zone.run(() => {
            this.userForm.reset();
            this.router.navigate(['/']);
          });
        });
    }
  }

}
