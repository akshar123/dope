import { tokenName } from '@angular/compiler';
import { Component } from '@angular/core';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {
  user = null;
  router: any;
  constructor(private auth: AuthService) {}

  ionViewDidEnter() {
    this.auth.getUsers().subscribe((response) => {
      this.user = response;
    });
  }
  // logout() {
  //   this.auth.logout();
  // }
  removeUser(user) {
    if (window.confirm('Are you sure')) {
      this.auth.deleteUser(user.id)
      .subscribe(() => {
          this.ionViewDidEnter();
          this.router.navigate(['/']);
          console.log('User deleted!');
        }
      );
    }
  }
}
  