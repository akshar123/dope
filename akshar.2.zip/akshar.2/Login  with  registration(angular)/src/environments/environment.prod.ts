export const environment = {
  production: true,
  apiUrl: 'http://192.168.1.69:8081/LoginAndRegistrationV/'
};
